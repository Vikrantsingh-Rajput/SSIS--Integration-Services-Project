USE [SalestargetWarehouse]
GO

SELECT [FirstName],
       [LastName],
	   [SalesQuantity],
	   [SalesRevenue],
	   [Year]
  FROM [dbo].SalesTable
GO